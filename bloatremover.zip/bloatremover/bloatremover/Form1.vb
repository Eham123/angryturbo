﻿Imports System.Threading
Imports Microsoft.Win32

Public Class Form1
    Private Const V As String = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Process.Start("cmd", "/c rd /s %systemdrive%\$Recycle.bin")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Process.Start("cmd", "/c rd /s %systemdrive%\Temp")
        Process.Start("cmd", "/c rd /s %systemdrive%\Windows\Temp")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Process.Start("cmd", "/c rd /s %systemdrive%\Windows\prefetch")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", True).SetValue("LetAppsRunInBackground", 2, RegistryValueKind.DWord)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Process.Start("cmd", "/c powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Process.Start("cmd", "/c powercfg -setactive scheme_min")
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Process.Start("cmd", "/c powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61")
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Process.Start("cmd", "/c powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\Windows Error Reporting", True).SetValue("Disabled", 1, RegistryValueKind.DWord)
    End Sub
End Class
