﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        GroupBox1 = New GroupBox()
        Button7 = New Button()
        Button8 = New Button()
        Button6 = New Button()
        Button5 = New Button()
        Button9 = New Button()
        GroupBox2 = New GroupBox()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(6, 22)
        Button1.Name = "Button1"
        Button1.Size = New Size(74, 23)
        Button1.TabIndex = 0
        Button1.Text = "Empty Bin"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(86, 22)
        Button2.Name = "Button2"
        Button2.Size = New Size(81, 23)
        Button2.TabIndex = 4
        Button2.Text = "Empty Temp"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(170, 22)
        Button3.Name = "Button3"
        Button3.Size = New Size(97, 23)
        Button3.TabIndex = 5
        Button3.Text = "Empty Prefetch"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(6, 138)
        Button4.Name = "Button4"
        Button4.Size = New Size(150, 23)
        Button4.TabIndex = 6
        Button4.Text = "Disable Background Apps"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Button1)
        GroupBox1.Controls.Add(Button2)
        GroupBox1.Controls.Add(Button3)
        GroupBox1.Location = New Point(12, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(273, 51)
        GroupBox1.TabIndex = 15
        GroupBox1.TabStop = False
        GroupBox1.Text = "Cleaning Options"
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(6, 80)
        Button7.Name = "Button7"
        Button7.Size = New Size(172, 23)
        Button7.TabIndex = 10
        Button7.Text = "Unlock Ultimate Preformance"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(6, 109)
        Button8.Name = "Button8"
        Button8.Size = New Size(172, 23)
        Button8.TabIndex = 11
        Button8.Text = "Enable Ultimate Preformance"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(6, 51)
        Button6.Name = "Button6"
        Button6.Size = New Size(161, 23)
        Button6.TabIndex = 9
        Button6.Text = "Enable High Preformance"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(6, 22)
        Button5.Name = "Button5"
        Button5.Size = New Size(161, 23)
        Button5.TabIndex = 7
        Button5.Text = "Unlock High Preformance"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(6, 167)
        Button9.Name = "Button9"
        Button9.Size = New Size(136, 23)
        Button9.TabIndex = 13
        Button9.Text = "Disable Error Reporting"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.BackColor = SystemColors.HotTrack
        GroupBox2.Controls.Add(Button5)
        GroupBox2.Controls.Add(Button9)
        GroupBox2.Controls.Add(Button6)
        GroupBox2.Controls.Add(Button7)
        GroupBox2.Controls.Add(Button4)
        GroupBox2.Controls.Add(Button8)
        GroupBox2.Location = New Point(12, 69)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(204, 197)
        GroupBox2.TabIndex = 16
        GroupBox2.TabStop = False
        GroupBox2.Text = "Preformance Options"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.HotTrack
        ClientSize = New Size(405, 426)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        Name = "Form1"
        Text = "AngryTurbo v1.0"
        GroupBox1.ResumeLayout(False)
        GroupBox2.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents GroupBox2 As GroupBox

End Class
